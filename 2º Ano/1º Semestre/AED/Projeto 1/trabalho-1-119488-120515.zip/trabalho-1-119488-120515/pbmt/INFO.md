# Some PBM files for tests

This directory contains PBM files to test the `imageBW` module.
See `Makefile`.

