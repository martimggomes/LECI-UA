# Example PBM (binary) files

This directory contains example PBM files.
Most or all of the files were dowloaded from [PBMB Files web page][pbmb].

[pbmb]: https://people.math.sc.edu/Burkardt/data/pbmb/pbmb.html

